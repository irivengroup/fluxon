<?php

declare(strict_types=1);

namespace Iriven\PhpFormGenerator\Domain\Form;

final class FormView
{
    /** @var array<string, mixed> */
    public array $options;

    /**
     * @param array<string, mixed> $vars
     * @param array<int, FormView> $children
     * @param array<int, string> $errors
     * @param array<int, Fieldset> $fieldsets
     */
    public function __construct(
        public readonly string $name,
        public readonly string $fullName,
        public readonly string $id,
        public readonly string $type,
        public readonly mixed $value,
        public readonly array $vars = [],
        public readonly array $children = [],
        public readonly array $errors = [],
        public readonly array $fieldsets = [],
        public readonly bool $submitted = false,
        public readonly bool $valid = true,
    ) {
        $this->options = $this->vars;
    }
}
